<?php
class Kroeg{
  public static $toestemming = "Kroegen mogen bezocht worden!";

  public static function toestemming(){
    return $this->toestemming;
  }
}



?>
